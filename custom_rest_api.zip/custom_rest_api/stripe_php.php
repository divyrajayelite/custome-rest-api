<?php
require('stripe-php-master/init.php');

// namespace Stripe;
\Stripe\Stripe::setApiKey("sk_test_40MILgxHIB2I2WsXLrIL4cWO");


function crerate_customer($desc,$email,$token,$card_number,$exp_month,$exp_year,$cvc){
    return \Stripe\Customer::create([
        'description' => $desc,
        'email' => $email,
        'source' => $token,
    ]);
}

function add_card_to_customer($customer_id,$card_token){
    try{
        $customer = \Stripe\Customer::retrieve($customer_id);
        return $customer->sources->create(["source" => $card_token]);
    }catch(Exception $m){
        return $m;
    }
}

function set_card_to_defult($customer_id,$card_id){
    try{
        return \Stripe\Customer::update(
            $customer_id,
            [
              'default_source' => $card_id
            ]
          );
    }catch(Exception $m){
        return $m;
    }
    
}

function create_card_token($card_number,$exp_month,$exp_year,$cvc){
    return \Stripe\Token::create([
        'card'=>[
            'number' => $card_number,
            'exp_month' => $exp_month,
            'exp_year' => $exp_year,
            'cvc' => $cvc
        ]
    ]);
}

// function set_card_to_default($customer_id,$card_id){
//     return \Stripe\Customer::update([
//         $customer_id,
//         [
//             'default_source' => $card_id;
//         ]
//     ]);

// }

function create_charge($customer_id,$amount,$currency,$description){
    try{
        return \Stripe\Charge::create([
            "amount" => $amount,
            "currency" => $currency,
            "customer" => $customer_id,
            "description" => $description
        ]);
    }catch(Exception $m){
        return $m;
    }
}

function retrive_all_card($customer_id){
    try{
        return \Stripe\Customer::retrieve($customer_id)->sources->all();
    }catch(Exception $m){
        return $m;
    }
}

function retrive_all_customer($customer_id){
    try{
        return \Stripe\Customer::retrieve($customer_id);
    }catch(Exception $m){
        return $m;
    }
}

?>