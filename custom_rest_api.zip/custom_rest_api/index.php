<?php
/**
* Plugin Name: Custome Rest Api
* Description: This is the very first plugin I ever created.
* Version: 1.0
* Author: Divyraj Chavda
**/
 require('stripe_php.php');
Class My_Rest_Controller
 {
    /*
    *in this construct we define api name like 
    *'your-api-name/v1(if you want to add version
    * the add otherwise v1 is optional)'
    */ 
    public function __construct()
    {
        $this->namespace = '/custom-api/v1';
    }

    /*
        *Register Rest Route
    */
    public function register_routes()
    {

        register_rest_route( $this->namespace, '/all_demo', array(
            array(
                'methods'   => 'POST',
                'callback'  => array( $this, 'test_demo' ),
                // 'permission_callback' => array( $this, 'get_items_permissions_check' ),
            )
        ) );

        register_rest_route($this->namespace,'create_account',array(
            array(
                'methods' => 'POST',
                'callback' => array($this,'create_users'),
                //'pemission callback' => array($this,'get_items_permissions_check'),
            )
        ));

        register_rest_route($this->namespace,'login',array(
            array(
                'methods' => 'POST',
                'callback' => array($this,'login'),
                //'pemission callback' => array($this,'get_items_permissions_check'),
            )
        ));

        register_rest_route($this->namespace,'reset_password',array(
            array(
                'methods' => 'POST',
                'callback' => array($this,'reset_password'),
                //'pemission callback' => array($this,'get_items_permissions_check'),
            )
        ));

        register_rest_route( $this->namespace, '/check_reset_password', array(
            array(
                'methods' => 'POST',
                'callback' => array( $this, 'check_reset_password_string'),
            )
        ) );

        register_rest_route( $this->namespace, '/update_user_password', array(
            array(
                'methods' => 'POST',
                'callback' => array( $this, 'update_password'),
            )
        ) );
        
        register_rest_route($this->namespace,'get_posts',array(
            array(
                'methods' => 'POST',
                'callback' => array($this,'get_all_posts'),
                //'pemission callback' => array($this,'get_items_permissions_check'),
            )
        ));

        register_rest_route($this->namespace,'get_categories',array(
            array(
                'methods' => 'POST',
                'callback' => array($this,'get_all_categories'),
                //'pemission callback' => array($this,'get_items_permissions_check'),
            )
        ));
        
        register_rest_route($this->namespace,'create_customer',array(
            array(
                'methods' => 'POST',
                'callback' => array($this,'create_stripe_customer'),
                //'pemission callback' => array($this,'get_items_permissions_check'),
            )
        ));
        
        register_rest_route($this->namespace,'create_stripe_token',array(
            array(
                'methods' => 'POST',
                'callback' => array($this,'create_token'),
                //'pemission callback' => array($this,'get_items_permissions_check'),
            )
        ));
        
        register_rest_route($this->namespace,'add_stripe_card',array(
            array(
                'methods' => 'POST',
                'callback' => array($this,'add_sripe_card_customer'),
                //'pemission callback' => array($this,'get_items_permissions_check'),
            )
        ));
        
        register_rest_route($this->namespace,'set_default_card',array(
            array(
                'methods' => 'POST',
                'callback' => array($this,'set_card_default'),
                //'pemission callback' => array($this,'get_items_permissions_check'),
            )
        ));
        
        register_rest_route($this->namespace,'customer_charge',array(
            array(
                'methods' => 'POST',
                'callback' => array($this,'create_customer_charge'),
                //'pemission callback' => array($this,'get_items_permissions_check'),
            )
        ));
        
        register_rest_route($this->namespace,'get_card',array(
            array(
                'methods' => 'POST',
                'callback' => array($this,'get_all_card'),
                //'pemission callback' => array($this,'get_items_permissions_check'),
            )
        ));
        
        register_rest_route($this->namespace,'get_customer',array(
            array(
                'methods' => 'POST',
                'callback' => array($this,'get_all_customer'),
                //'pemission callback' => array($this,'get_items_permissions_check'),
            )
        ));
    }
    
    public function test_demo(){
        return "Testing api";
    }

    /**This Is Function The Check the permission Callback */
    public function get_items_permissions_check( $request ) {
        if ( ! current_user_can( 'read' ) ) {
            return new WP_Error( 'rest_forbidden', esc_html__( 'You cannot view the post resource.' ), array( 'status' => $this->authorization_status_code() ) );
        }
        return true;
    }
    /**This Function response to Error on Param  */
    public function err_param_response(){
        return $res = [
            "status" => 400,
            "message" => "Requested Params Not Found. Please Check All Prams."
        ];
    }
    /**This Function response to Error on any query */
    public function err_query_response(){
        return $res = [
            "status" => 500,
            "message" => "Something Went Wrong. Please Contact Admin."
        ];
    }

    /**This API To Create Users  */
    public function create_users(){
        global $wpdp;
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $mobile = $_POST['mobile'];

        if($username != null && $email != null && $password != null && $mobile != null){
            $exist = email_exists($email);
            if($exist){
                $data = $email." Email already Register In Database.";
                return $data;
            }else{
                $user_id = wp_create_user($username,$password,$email,$mobile);
                if(!is_object($user_id)){
                    return $user_id;
                }else{
                    return $user_id;
                }
            }

            
        }else{
            return $this->err_param_response();
        }
    }

    /**This API Is to Login  */
    public function login(){
        global $wpdb;
        $email = $_POST['email'];
        $password = $_POST['password'];
        if($email != null && $password != null){
            $user = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."users WHERE user_email = '".$email."'");
            
            if($user && $user->user_pass != null){
                $check = wp_check_password($password,$user->user_pass);
                if($check){
                    return $user;
                }else{
                    return "Enterd Password : ".$password." is not valid for email : ".$email.".";
                }
            }else{
                return "Entered Email : ".$email." is not registred in database.";
            }
        }else{
            return $this->err_param_response();
        }
    }

    /*Forgot Password api*/

    function generateRandomString($length = 5) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }

    public function reset_password(){
        global $wpdb;
        $email = $_POST['email'];
        if($email != null){
            $data = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."users WHERE user_email='".$email."'");
            if($data != null){
                $random = $this->generateRandomString(5);
                $result = update_user_meta($data->ID,'reset_password_token',$random);
                if($result != null){
                    // send mail with random string.
                    return $res = [
                        'status' => 200,
                        'message' => "Email Send Successfully....",
                        'data' => $random
                    ];
                }else{
                    return $res = [
                        'status' => 500,
                        'message' => "Something Went Wrong !"
                    ];
                }
                
            }else{
                return $res = [
                    'status' => 400,
                    'message' => 'This Email is Not Registered in Database Please Use Another Email.'
                ];
            }
        }else{
            return $res = [
                'status' => 500,
                'message' => 'Required Email For Reset Password , Please Enter Email.'
            ];
        }
    }

    public function check_reset_password_string(){
        global $wpdb;
        $string = $_POST['otp'];
        $email = $_POST['email'];
        if($string != null && $email != null){
            $data = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."users WHERE user_email='".$email."'");
            if($data != null){
                $stored_string = get_user_meta($data->ID,'reset_password_token',true);
                if($stored_string == $string){
                    return $res = [
                        'status' => 200,
                        'message' => 'Opt Matched.',
                        'data' => $data
                    ];
                }else{
                    return $res = [
                        'status' => 400,
                        'message' => 'Opt is Not Matched Enter Again.'
                    ];
                }
            }else{
                return $res = [
                    'status' => 400,
                    'message' => 'This Email is Not Registered in Database Use Another Email;.'
                ];
            }
        }else{
            return $res = [
                'status' => 500,
                'message' => 'Requested Param Missing Full Fill All Fields.'
            ];
        }
    }

    public function update_password(){
        $user_id = $_POST['user_id'];
        $new_password = $_POST['password'];
        if($user_id != null && $new_password != null){
            $data = wp_set_password($new_password,$user_id);
            return $res = [
                'status' => 200,
                'message' => 'Password Changed Sucessfully.'
            ];
        }else{
            return $res = [
                'status' => 400,
                'message' => 'Requested Params Missing Full Fill All Fields.'
            ];
        }
    }

    /*Retrive all posts from front */
    public function get_all_posts(){
        global $wpdb;
        $posts = get_posts();
        $result = [];
        $i=0;
        foreach($posts as $post){
            $result[$i]['post'] =$post;
            $result[$i]['post_title']= $post->post_title;
            $result[$i]['post_content'] = str_replace("\n","",strip_tags($post->post_content));
            $i++;
        }
        return $result;

    }

    /*Retrive all all categories  */
    public function get_all_categories(){
        global $wpdb;
        $test = get_terms(array(
            'taxonomy' => 'category',
            'hide_empty' => 'false',
        ));
        return $test;
    }

    /*Create card token on stripe api */
    public function create_token(){
        $card_number =$_POST['card_number'];
        $exp_month = $_POST['exp_month'];;
        $exp_year = $_POST['exp_year'];
        $cvc = $_POST['cvc'];

        try{
            $crd_tkn = create_card_token($card_number,$exp_month,$exp_year,$cvc);
            return $crd_tkn;
        }catch(Exception $m){
            return $m;
        }
    }

    /*Create stripe card customer api */
    public function create_stripe_customer(){
        $desc = $_POST['desc'];
        $email = $_POST['email'];
        $card_number = $_POST['card_number'];
        $exp_month = $_POST['exp_month'];
        $exp_year = $_POST['exp_year']; 
        $cvc = $_POST['cvc'];
        $user_id= $_POST['user_id'];
        $token = $_POST['token'];
        if($desc != null && $email != null && $card_number != null && $exp_month != null && $exp_year != null && $cvc != null && $user_id != null && $token != null){
            $ids = crerate_customer($desc,$email,$token,$card_number,$exp_month,$exp_year,$cvc);
            $usmeta= update_user_meta($user_id,'strip_cus_id',$ids->id);
            return $ids;
        }else{
            return $this->err_param_response();
        }
        
    }

    /*add customer stripe card api */
    public function add_sripe_card_customer(){
        $customer_id = $_POST['customer_id'];
        $card_token = $_POST['card_token'];
        if($customer_id != null && $card_token != null){
            $str_crd = add_card_to_customer($customer_id,$card_token);
            return $str_crd;
        }else{
            return $this->err_param_response();
        }     
    }

    /* set default card for customer */
    public function set_card_default(){
        $customer_id = $_POST['customer_id'];
        $card_id = $_POST['card_id'];
        if($customer_id !=null && $card_id != null){
            return set_card_to_defult($customer_id,$card_id);
        }else{
            return $this->err_param_response();
        }
    }

    /* set customer charge on any product  */
    public function create_customer_charge(){
        $customer_id = $_POST['customer_id'];
        $amount = $_POST['amount'];
        $currency = $_POST['currency'];
        $description = $_POST['description'];
        if($customer_id != null && $amount != null && $currency != null && $description != null){
            return create_charge($customer_id,$amount,$currency,$description);
        }else{
            return $this->err_param_response();
        }
    }

    /**get all stripe card customer */
    public function get_all_card(){
        $customer_id = $_POST['customer_id'];
        if($customer_id != null){
            return retrive_all_card($customer_id);
        }else{
            return $this->err_param_response();
        }
    }

    /**get all customer who have card detail */
    public function get_all_customer(){
        $customer_id = $_POST['customer_id'];

        if($customer_id != null){
            return retrive_all_customer($customer_id);
        }else{
            return $this->err_param_response();
        }
    }

    
 
}

function prefix_register_my_rest_routes() {
    $controller = new My_Rest_Controller();
    $controller->register_routes();
}
 
add_action( 'rest_api_init', 'prefix_register_my_rest_routes' );

?>